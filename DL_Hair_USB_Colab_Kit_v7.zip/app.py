# app.py — v7: Arabic-safe PDF (reshaper+bidi+TTF), capture-only, adaptive guard
import os, sys, json
import numpy as np
import cv2
import torch
from PIL import Image
import gradio as gr
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from torchvision import transforms
from torchvision.models import resnet50, ResNet50_Weights
import arabic_reshaper
from bidi.algorithm import get_display

MODEL_PATH  = os.getenv("HAIR_MODEL_PATH",  "hair_disease_model.pth")
LABELS_PATH = os.getenv("HAIR_LABELS_PATH", "labels_bilingual.json")
SHARE       = os.getenv("GRADIO_SHARE", "true").lower() in ["1", "true", "yes"]

# -------- font setup (expects fonts/NotoNaskhArabic-Regular.ttf) --------
FONT_DIR = os.path.join(os.path.dirname(__file__), "fonts")
AR_TTF   = os.path.join(FONT_DIR, "NotoNaskhArabic-Regular.ttf")
EN_FONT  = "Helvetica"  # built-in
AR_FONT  = "NotoNaskhArabic"

def ensure_ar_font():
    if os.path.exists(AR_TTF):
        try:
            pdfmetrics.registerFont(TTFont(AR_FONT, AR_TTF))
            return True
        except Exception as e:
            print(f"[!] Failed to register Arabic font: {e}", file=sys.stderr)
    else:
        print(f"[i] Arabic font not found at {AR_TTF}. PDF will fallback to English-only.", file=sys.stderr)
    return False

HAS_AR_FONT = ensure_ar_font()

def ar_shape(text: str) -> str:
    # Shape + bidi for proper Arabic rendering
    try:
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text

# ---------- Labels (bilingual) ----------
if os.path.exists(LABELS_PATH):
    with open(LABELS_PATH, "r", encoding="utf-8") as f:
        LBL = json.load(f)
else:
    LBL = [
        {"en": "Alopecia Areata",      "ar": "الثعلبة البقعية"},
        {"en": "Contact Dermatitis",   "ar": "التهاب الجلد التماسي"},
        {"en": "Folliculitis",         "ar": "التهاب الجريبات"},
        {"en": "Head Lice",            "ar": "قمل الرأس"},
        {"en": "Lichen Planus",        "ar": "الحزاز المسطح"},
        {"en": "Male Pattern Baldness","ar": "الصلع الوراثي (الذكوري)"},
        {"en": "Psoriasis",            "ar": "الصدفية"},
        {"en": "Seborrheic Dermatitis","ar": "التهاب الجلد الدهني"},
        {"en": "Telogen Effluvium",    "ar": "تساقط التيلوجين"},
        {"en": "Tinea Capitis",        "ar": "سعفة الرأس"}
    ]

CLASSES_EN = [x["en"] for x in LBL]  # model order
CLASSES_AR = [x["ar"] for x in LBL]
NUM_CLASSES = len(CLASSES_EN)

# ---------- Model ----------
class Head(torch.nn.Module):
    def __init__(self, in_dim=1000, out_dim=10):
        super().__init__()
        self.fc = torch.nn.Linear(in_dim, out_dim)
    def forward(self, x):
        return self.fc(x)

class FullModel(torch.nn.Module):
    def __init__(self, out_dim=10):
        super().__init__()
        self.backbone = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
        self.head = Head(1000, out_dim)
    def forward(self, x):
        feats = self.backbone(x)
        out = self.head(feats)
        return out

def load_model():
    model = FullModel(out_dim=NUM_CLASSES)
    if os.path.exists(MODEL_PATH):
        try:
            obj = torch.load(MODEL_PATH, map_location="cpu")
            if isinstance(obj, dict) and "state_dict" in obj:
                model.load_state_dict(obj["state_dict"], strict=False)
            elif isinstance(obj, dict):
                model.load_state_dict(obj, strict=False)
            else:
                model = obj
            print(f"[OK] Loaded weights from {MODEL_PATH}", file=sys.stderr)
        except Exception as e:
            print(f"[!] Failed to load weights from {MODEL_PATH}: {e}", file=sys.stderr)
    model.eval()
    return model

model = load_model()

# ---------- Preprocess ----------
transform = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
])

# ---------- Adaptive guard ----------
def is_valid_frame(image_np: np.ndarray, sensitivity: float = 0.35) -> bool:
    if image_np is None or image_np.ndim != 3 or image_np.shape[2] != 3:
        return False
    gray_u8 = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
    gray = gray_u8.astype(np.float32)
    mean_intensity = float(gray.mean())
    std_intensity  = float(gray.std())
    dark_ratio     = float((gray_u8 < 35).mean())
    bright_ratio   = float((gray_u8 > 245).mean())
    lap_var = float(cv2.Laplacian(gray_u8, cv2.CV_64F).var())
    edges = cv2.Canny(gray_u8, 50, 150)
    edge_density = float((edges > 0).mean())
    diff_ratio = float(((gray > mean_intensity - 12) & (gray < mean_intensity + 12)).mean())
    base_std_min, base_lap_min, base_edge_min = 6.0, 12.0, 0.0025
    base_diff_max, base_dark_max, base_bright_max = 0.95, 0.995, 0.995
    k = 0.5 + sensitivity
    std_min  = base_std_min  * k
    lap_min  = base_lap_min  * k
    edge_min = base_edge_min * (0.7 + 0.6*sensitivity)
    diff_max = base_diff_max - 0.06*(sensitivity)
    if mean_intensity < 15 or mean_intensity > 245: return False
    if dark_ratio > base_dark_max or bright_ratio > base_bright_max: return False
    strong_detail = (lap_var >= lap_min) or (edge_density >= edge_min)
    if not strong_detail: return False
    if std_intensity < std_min: return False
    if diff_ratio > diff_max: return False
    return True

# ---------- PDF (Arabic-aware) ----------
def generate_pdf(image_np, probs_en, topk_pairs, lang="both", save_dir="reports"):
    os.makedirs(save_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_path = os.path.join(save_dir, f"hair_report_{ts}.pdf")

    c = canvas.Canvas(pdf_path, pagesize=A4)
    W, H = A4
    M = 2*cm
    x, y = M, H - M

    # title
    c.setFillColor(colors.black)
    c.setFont(EN_FONT, 16)
    c.drawString(x, y, "Scalp Disease Inference Report (ResNet50)")
    y -= 20
    c.setFont(EN_FONT, 10)
    c.drawString(x, y, f"Timestamp: {datetime.now().isoformat(timespec='seconds')}")
    y -= 30

    # image
    tmp_img = os.path.join(save_dir, f"tmp_{ts}.jpg")
    Image.fromarray(image_np.astype('uint8')).save(tmp_img, "JPEG", quality=90)
    img_w = W - 2*M
    img_h = (H/2) - M
    c.drawImage(tmp_img, x, y - img_h + 10, width=img_w, height=img_h, preserveAspectRatio=True, anchor='nw')
    y -= img_h + 10

    # helper label
    def fmt_label(i):
        if lang == "en": return CLASSES_EN[i]
        if lang == "ar": return CLASSES_AR[i]
        return f"{CLASSES_EN[i]} / {CLASSES_AR[i]}"

    # Top predictions
    c.setFont(EN_FONT, 12)
    c.drawString(x, y, "Top Predictions")
    y -= 16
    c.setFont(EN_FONT, 10)
    c.drawString(x, y, "Class")
    c.drawString(x + 300, y, "Probability")
    y -= 14
    c.line(x, y, x + 380, y)
    y -= 8

    for i, p in topk_pairs:
        label = fmt_label(i)
        # draw EN/AR properly
        if "/" in label and HAS_AR_FONT and (lang in ("both","ar")):
            en_part, ar_part = label.split("/", 1)
            # left side English
            c.setFont(EN_FONT, 10)
            c.drawString(x, y, en_part.strip())
            # right side Arabic (RTL)
            c.setFont(AR_FONT, 10)
            c.drawRightString(x + 280, y, ar_shape(ar_part.strip()))
        else:
            # single-language line
            c.setFont(AR_FONT if (lang=="ar" and HAS_AR_FONT) else EN_FONT, 10)
            txt = ar_shape(label) if (lang=="ar" and HAS_AR_FONT) else label
            c.drawString(x, y, txt)
        # prob
        c.setFont(EN_FONT, 10)
        c.drawString(x + 300, y, f"{p:.3f}")
        y -= 14

    # All probs (two columns)
    y -= 12
    c.setFont(EN_FONT, 12)
    c.drawString(x, y, "All Probabilities")
    y -= 16
    items = list(enumerate(probs_en))
    mid = len(items)//2 + len(items)%2
    col1, col2 = items[:mid], items[mid:]

    def draw_col(x0, rows):
        yy = y
        for i, p in rows:
            label = fmt_label(i)
            if "/" in label and HAS_AR_FONT and (lang in ("both","ar")):
                en_part, ar_part = label.split("/", 1)
                c.setFont(EN_FONT, 9);  c.drawString(x0, yy, en_part.strip())
                c.setFont(AR_FONT, 9);  c.drawRightString(x0 + 190, yy, ar_shape(ar_part.strip()))
            else:
                c.setFont(AR_FONT if (lang=="ar" and HAS_AR_FONT) else EN_FONT, 9)
                txt = ar_shape(label) if (lang=="ar" and HAS_AR_FONT) else label
                c.drawString(x0, yy, txt)
            c.setFont(EN_FONT, 9); c.drawString(x0 + 200, yy, f"{p:.3f}")
            yy -= 12

    draw_col(x, col1)
    draw_col(x + 260, col2)

    c.showPage()
    c.save()
    try: os.remove(tmp_img)
    except: pass
    return pdf_path

# ---------- Inference ----------
def analyze_snapshot(image_np, top_k=3, threshold=0.5, sensitivity=0.35, disable_guard=False, lang="both"):
    if image_np is None:
        return "الرجاء التقاط صورة أولاً.", {}, None
    if not disable_guard and not is_valid_frame(image_np, float(sensitivity)):
        return "الإطار غير صالح وفق الفلتر (قلّل الحساسية أو عطّل الفلتر مؤقتاً).", {}, None

    im = Image.fromarray(image_np.astype(np.uint8)).convert("RGB")
    x = transform(im).unsqueeze(0)
    with torch.no_grad():
        logits = model(x)
        probs = torch.sigmoid(logits).cpu().numpy().squeeze()

    probs = np.array(probs).reshape(-1)
    if probs.size != len(CLASSES_EN):
        probs = probs[:len(CLASSES_EN)]

    top_idx = probs.argsort()[::-1][:int(top_k)]
    top_pairs = [(int(i), float(probs[i])) for i in top_idx]

    def display_label(i, lang):
        if lang == "en": return CLASSES_EN[i]
        if lang == "ar": return CLASSES_AR[i]
        return f"{CLASSES_EN[i]} / {CLASSES_AR[i]}"

    top_dict = {display_label(i, lang): p for i, p in top_pairs}

    pdf_path = generate_pdf(image_np, probs_en=probs, topk_pairs=top_pairs, lang=lang)

    if not any(p >= float(threshold) for p in probs):
        text = "لا توجد فئات تجاوزت العتبة المحددة."
    else:
        passed = [(i, float(probs[i])) for i in range(len(probs)) if probs[i] >= float(threshold)]
        passed.sort(key=lambda x: x[1], reverse=True)
        text = "الفئات المتجاوزة للعتبة: " + ", ".join([f"{display_label(i, lang)}: {v:.3f}" for i, v in passed])

    return text, top_dict, pdf_path

# ---------- UI ----------
with gr.Blocks(title="Hair Scalp Diseases – Capture & Arabic-safe PDF",
               css="footer {visibility: hidden}") as demo:
    gr.Markdown("""
    # Hair Scalp Diseases (ResNet50) — Capture Only + Bilingual PDF (Arabic-safe)
    **خطوات:** (1) التقط صورة (Take Photo) (2) Analyze (3) نزّل PDF.
    """)
    with gr.Row():
        cam = gr.Image(
            label="التقاط من الكاميرا (Take Photo ثم Analyze)",
            sources=["webcam"],
            streaming=False,
            mirror_webcam=True,
            height=380,
            type="numpy"
        )
        with gr.Column():
            threshold = gr.Slider(0.0, 1.0, value=0.50, step=0.01, label="عتبة الاحتمال / Threshold")
            topk = gr.Slider(1, len(CLASSES_EN), value=3, step=1, label="Top-K")
            sensitivity = gr.Slider(0.0, 1.0, value=0.35, step=0.05, label="حساسية فلتر الإطار (0=متساهل، 1=صارم)")
            disable_guard = gr.Checkbox(value=False, label="تعطيل فلتر الإطار مؤقتًا (Bypass)")
            lang = gr.Radio(choices=["both", "en", "ar"], value="both", label="لغة العرض في النتائج والتقرير")
            analyze_btn = gr.Button("Analyze", variant="primary")
            result_text = gr.Textbox(label="النتيجة / Result", lines=3)
            topk_out = gr.Label(label="Top-K (EN/AR)")
            pdf_out = gr.File(label="PDF Report (EN/AR)", interactive=False)

    analyze_btn.click(
        fn=analyze_snapshot,
        inputs=[cam, topk, threshold, sensitivity, disable_guard, lang],
        outputs=[result_text, topk_out, pdf_out]
    )

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860, share=SHARE, show_error=True)
