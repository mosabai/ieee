# DL Hair USB Colab Kit — v7 (Arabic-safe PDF)
Adds Arabic shaping (arabic-reshaper + python-bidi) and TTF embedding for correct Arabic text in PDFs.

## Download Arabic font (required once in Colab)
```python
!mkdir -p /content/hairapp/fonts
!wget -q https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoNaskhArabic/NotoNaskhArabic-Regular.ttf -O /content/hairapp/fonts/NotoNaskhArabic-Regular.ttf
```

## Run
```python
!unzip -o DL_Hair_USB_Colab_Kit_v7.zip -d /content/hairapp
%cd /content/hairapp
!pip install -q -r requirements.txt
# download the TTF once (see above)
!python app.py
```
